## python-espncricinfo changelog

#### 2018-08-09

* Added methods for retrieving matches in a series. ([Issue 19](https://github.com/dwillis/python-espncricinfo/issues/19))

#### 2018-08-05

* Converted batting and bowling averages into a single dictionary. ([Issue 25](https://github.com/dwillis/python-espncricinfo/issues/25))
